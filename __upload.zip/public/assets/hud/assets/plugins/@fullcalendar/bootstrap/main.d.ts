import * as _fullcalendar_common from '@fullcalendar/common';
import { Theme } from '@fullcalendar/common';

declare class BootstrapTheme extends Theme {
}
declare const plugin: _fullcalendar_common.PluginDef;

export default plugin;
export { BootstrapTheme };
