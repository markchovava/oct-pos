declare const _default: import("@fullcalendar/common").LocaleInput[];
export default _default;
