<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Operation\Operation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserStatusController extends Controller
{
    
    public $a = 'id, user_id, start_time, end_time, status';

    public function status(Request $request){
        $status = $request->status;
        if($status == 1){
            $operation = Operation::where('user_id', Auth::user()->id)->first();
            $operation->status = 0;
            $operation->save();
            $user_status = $operation->status;
        }
        elseif($status == 0){
            $operation = new Operation();
            $operation->start_time = now();
            $operation->status = 1;
            $operation->save();
            $user_status = $operation->status;
        }

        $data['current_status'] = $user_status;
        return response()->json($data);
    }
}
